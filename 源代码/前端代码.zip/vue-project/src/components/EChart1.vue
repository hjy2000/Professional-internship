<template>
  <div>
    EChart1
  </div>
</template>

<script>
export default {
  name: 'EChart1'
}
</script>

<style scoped>

</style>
