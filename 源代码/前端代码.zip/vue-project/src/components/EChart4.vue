<template>
  <el-row>
    <div>
      <h3>前5个职业真假</h3>
      <div id="EChart4" style="width:100%;height:500px;margin-top:10px;"></div>
    </div>
  </el-row>
</template>

<script>
import * as echarts from 'echarts'

export default {
  name: 'EChart4',
  data () {
    return {
      charts4: ''
    }
  },
  methods: {
    initChart () {
      this.charts4 = echarts.init(document.getElementById('EChart4'))
      let option = {
        xAxis: {
          name: 'elements'
        },
        yAxis: {
          name: 'judgement',
          min: 0,
          max: 1,
          axisLabel: {
            formatter: function (value) {
              var texts = []
              if (value === 0) {
                texts.push('False')
              } else if (value === 1) {
                texts.push('True')
              }
              return texts
            }
          }
        },
        series: [
          {
            symbolSize: 20,
            data: [
              [1, 1],
              [2, 1],
              [3, 0],
              [4, 0],
              [5, 0]
            ],
            type: 'scatter'
          }
        ]
      }
      this.charts4.setOption(option)
    }
  },
  // 调用
  mounted () {
    this.$nextTick(function () {
      this.initChart()
    })
  }
}
</script>

<style scoped>

</style>
