<template>
  <div style="margin-top: 20px;">
    <h3>本项目主要内容包括：</h3>
    <br>
    <p style="margin-top: 0px;">根据提供的职位信息来判断这个职位是否真实存在</p>
    <!-- <textarea style="width:300px;height:100px;"></textarea> -->
    <div class="video_text" style="text-align:center;margin:0 auto;border:1px solid white;width:300px;height:100px;">
				<div class="text_middle">
					由于目前社会上有存在一定程度的职位信息造假现象，在职位信息上存在一定程度的欺诈行为。为了解决这个问题，辨识出哪些职位信息是假的，存在欺诈行为的，哪些职业信息是真的，是确切可信的，这个项目就是为此而诞生的。因此，该真假职位信息检测系统能够使得有欺诈行为的职业信息被暴露出来，解决了职位信息造假欺诈的问题。
				</div>
			</div>
  </div>

</template>

<script>

export default {
  name: 'HomePage',
  data () {
    return {
    }
  },
  methods: {
  }
}
</script>

<style scoped>
.video_text{
				width: 40%;
				height: 400px;
				color: #666666;
				font-family: "微软雅黑";
				font-weight: bold;
				text-align: center;
				text-indent: 2em;
				line-height: 24px;
				float: center;
				border: 1px solid white;
				display: table;
			}
			.text_middle{
				display: table-cell;
				vertical-align: middle;
        
			}
</style>
