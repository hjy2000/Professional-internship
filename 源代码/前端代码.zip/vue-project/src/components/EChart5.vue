<template>
  <el-row>
    <div>
      <h3>统计职位真假</h3>
      <div id="EChart5" style="width:100%;height:500px;margin-top:10px;"></div>
    </div>
  </el-row>
</template>

<script>
import * as echarts from 'echarts'

export default {
  name: 'EChart5',
  data () {
    return {
      charts5: ''
    }
  },
  methods: {
    initChart () {
      this.$http.post("http://127.0.0.1:5000/g1").then(
        function(res) {
          var chartDom = document.getElementById('EChart5');
          var myChart = echarts.init(chartDom);
          var option;
          var data = eval("(" + res.data + ")");
          var amount = data.data;

          option = {
            xAxis: {
              type: "category",
              name: "judgement",
              data: ["True", "False"]
            },
            yAxis: {
              type: "value",
              name: "amount"
            },
            series: [
              {
                data: [
                  amount[0][0],
                  {
                    value: amount[1][0],
                    itemStyle: {
                      color: "#a90000"
                    }
                  }
                ],
                type: "bar",
                itemStyle: {
                  normal: {
                    label: {
                      show: true,
                      position: "top",
                      textStyle: {
                        color: "black",
                        fontSize: 14
                      }
                    }
                  }
                }
              }
            ]
          };

          myChart.setOption(option);
        },
        err => {
          console.log("error");
        }
      );
    }
  },
  // 调用
  mounted () {
    this.$nextTick(function () {
      this.initChart()
    })
  }
}
</script>

<style scoped>

</style>
