<template>
  <div>
    <el-container style="max-height: 700px; border: 2px solid #eee">
      <el-container>
        <el-header>
          <el-menu class="el-menu-demo" mode="horizontal">

            <el-submenu index="1">
              <template slot="title"><i class="el-icon-folder-add"></i>上传文件</template>
              <el-menu-item index="1-1" @click="choose">选择文件</el-menu-item>
              <!-- <el-menu-item index="1-2" >EChart柱状图</el-menu-item> -->
            </el-submenu>

            <el-submenu index="2">
              <template slot="title"><i class="el-icon-menu"></i>结果展示</template>
              <!-- <el-menu-item index="2-1" @click="checkEChart1">importance rank</el-menu-item>
              <el-menu-item index="2-2" @click="checkEChart2">真假职位个数</el-menu-item> -->
              <el-menu-item index="2-3" @click="checkEChart3">importance rank</el-menu-item>
              <el-menu-item index="2-4" @click="checkEChart4">前5个职位检测</el-menu-item>
              <el-menu-item index="2-5" @click="checkEChart5">真假职位个数</el-menu-item>
            </el-submenu>

          </el-menu>
        </el-header>
      </el-container>
    </el-container>
  </div>
</template>
<script>
export default {
  name: 'Navigation',
  data () {
    return {
      msg: ''
    }
  },
  methods: {
    choose () {
      if (this.$route.path !== '/choosefile') {
        this.$router.push({ path: '/choosefile' })
      }
    },
    checkEChart1 () {
      if (this.$route.path !== '/EChart1') {
        this.$router.push({ path: '/EChart1' })
      }
    },
    checkEChart2 () {
      if (this.$route.path !== '/EChart2') {
        this.$router.push({ path: '/EChart2' })
      }
    },
    checkEChart3 () {
      if (this.$route.path !== '/EChart3') {
        this.$router.push({ path: '/EChart3' })
      }
    },
    checkEChart4 () {
      if (this.$route.path !== '/EChart4') {
        this.$router.push({ path: '/EChart4' })
      }
    },
    checkEChart5 () {
      if (this.$route.path !== '/EChart5') {
        this.$router.push({ path: '/EChart5' })
      }
    }
  }
}
</script>

<style scoped>

</style>
