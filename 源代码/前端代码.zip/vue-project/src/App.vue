<template>
  <div id="app">
<!--    <img src="./assets/logo.png">-->
    <!--<el-header style="margin-bottom: 10px; height: 30px; font-size: 20px">
      真假职位信息检测
    </el-header>-->
    <h2>真假职位信息检测</h2>
    <Navigation></Navigation>
    <router-view/>
  </div>
</template>

<script>
import Navigation from './components/Navigation'
export default {
  name: 'App',
  components: {Navigation}
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 10px;
}
</style>
