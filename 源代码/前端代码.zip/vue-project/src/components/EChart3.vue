<template>
  <el-row>
    <div>
      <h3>importance rank</h3>
      <div id="EChart3" style="width:100%;height:500px;margin-top:10px;"></div>
    </div>
  </el-row>
</template>

<script>
import * as echarts from 'echarts'

export default {
  name: 'EChart3',
  data () {
    return {
      charts3: ''
    }
  },
  methods: {
    initChart () {
      this.$http.post('http://127.0.0.1:5000/g2').then(function(res){
          var chartDom = document.getElementById('EChart3');
          var myChart = echarts.init(chartDom);
          var option;
          var data = eval("("+res.data+")");
          data = data.data;

          var xdata = new Array(data.length);
          var ydata = new Array(data.length);
          for (var i = 0; i < data.length; ++i) {
              xdata[i] = data[i][0];
              ydata[i] = data[i][1];
          }

          option = {
              title : {
                      show:true,
                      subtext: '(元素名字过长不予显示，详见文档）',
                      x: 'center',
                      y: 'top',
                      padding: 10
              },
              xAxis: {
                  show: false,
                  type: 'category',
                  name: 'elements',
                  nameLocation: 'start',
                  axisLabel: {
                        interval: 0,
                        formatter: function(value) {
                            return value.split("").join("\n");
                        }
                  },
                  data: xdata
                },
              yAxis: {
                type: 'value',
                name: 'importance'
              },
              series: [{
                data: ydata,
                type: 'bar'
              }],
              grid: {
                  top: '15%',
                  left: '10%',
                  right: '10%'
              }
          };

          myChart.setOption(option);
      }, err=>{console.log("error")});
   }
  },
  // 调用
  mounted () {
    this.$nextTick(function () {
      this.initChart()
    })
  }
}
</script>

<style scoped>
</style>