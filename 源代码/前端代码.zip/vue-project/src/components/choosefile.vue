<template>
  <div>
    <h1>选择文件</h1>
    <el-row :gutter="20" type="flex" justify=center >
      <el-col :span="5">
          <form name="myForm" action="http://127.0.0.1:5000/receive" method="post" enctype="multipart/form-data">
          <input type="file" @change="getFile($event)" id="file" />
        </form>
      </el-col>
      <el-col :span="1">
        <el-button @click="submitForm($event)">上传文件</el-button>
      </el-col>
    </el-row>
    <div id="g1" style="width: 100%; height: 500px;"></div>
  </div>
</template>

<script>
import * as echarts from 'echarts'
export default {
  name: "choosefile",
  methods: {
    getFile(event) {
      this.file = event.target.files[0];
      console.log(this.file);
    },
    submitForm(event) {
      event.preventDefault();
      let formData = new FormData();
      formData.append("file", this.file);

      let config = {
        headers: {
          "Content-Type": "multipart/form-data"
        }
      };

      this.$http.post("http://127.0.0.1:5000/receive", formData, config).then(
        function(res) {
          var chartDom = document.getElementById('g1');
          var myChart = echarts.init(chartDom);
          var option;
          var data = eval("(" + res.data + ")");
          var amount = data.data;

          option = {
            xAxis: {
              type: "category",
              name: "judgement",
              data: ["True", "False"]
            },
            yAxis: {
              type: "value",
              name: "amount"
            },
            series: [
              {
                data: [
                  amount[0][0],
                  {
                    value: amount[1][0],
                    itemStyle: {
                      color: "#a90000"
                    }
                  }
                ],
                type: "bar",
                itemStyle: {
                  normal: {
                    label: {
                      show: true,
                      position: "top",
                      textStyle: {
                        color: "black",
                        fontSize: 14
                      }
                    }
                  }
                }
              }
            ]
          };

          myChart.setOption(option);
        },
        err => {
          console.log("error");
        }
      );
    }
  }
};
</script>

<style scoped>
</style>
