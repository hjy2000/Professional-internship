
module.exports = {
  //配置跨域请求
  devServer:{
    post: 5000, //运行端口号
    host: '127.0.0.1',
    open: true, //配置自动启动浏览器
    https: false,
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:5000',//对应服务器端口地址
        ws: true,
        changeOrigin: true, //开启跨域
        pathRewrite: {
          '^/api': ''
        }
      }
    }

  }
};

