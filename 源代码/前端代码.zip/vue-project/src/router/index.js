import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'
import HomePage from '../components/HomePage'
import EChart1 from '../components/EChart1'
import EChart2 from '../components/EChart2'
import EChart3 from '../components/EChart3'
import EChart4 from '../components/EChart4'
import EChart5 from '../components/EChart5'
import choosefile from '../components/choosefile'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'HomePage',
      component: HomePage
    },
    {
      path: '/HelloWorld',
      name: 'HelloWorld',
      component: HelloWorld
    },
    {
      path: '/EChart1',
      name: 'EChart1',
      component: EChart1
    },
    {
      path: '/EChart2',
      name: 'EChart2',
      component: EChart2
    },
    {
      path: '/EChart3',
      name: 'EChart3',
      component: EChart3
    },
    {
      path: '/EChart4',
      name: 'EChart4',
      component: EChart4
    },
    {
      path: '/EChart5',
      name: 'EChart5',
      component: EChart5
    },
    {
      path: '/choosefile',
      name: 'choosefile',
      component: choosefile
    }
  ]
})
